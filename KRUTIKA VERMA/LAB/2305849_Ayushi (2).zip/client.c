// receiver.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define MAX_BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    // A socket file descriptor is an integer that uniquely identifies a socket.
    int sockfd;
    // The buffer to store messages being sent or received.
    char buffer[MAX_BUFFER_SIZE];
    // The length of the address structure.
    socklen_t addr_len;
    // This structure is used to hold IPv4 socket addresses.
    struct sockaddr_in server_addr, client_addr;

    // Check if the correct number of command-line arguments are provided.
    // The program name itself is the first argument, so we expect 3 total.
    if (argc != 3) {
        printf("Usage: %s <Receiver's IP> <Receiver's Port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // 1. Create a UDP socket.
    // AF_INET specifies the IPv4 protocol.
    // SOCK_DGRAM specifies a datagram (UDP) socket.
    // 0 specifies the default protocol for the socket type.
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize the server_addr structure to zero.
    memset(&server_addr, 0, sizeof(server_addr));

    // 2. Configure the server address structure.
    // Use the address family AF_INET (IPv4).
    server_addr.sin_family = AF_INET;
    // Use `inet_addr` to convert the IP address from string to binary form.
    // The IP address is passed as the first command-line argument.
    server_addr.sin_addr.s_addr = inet_addr(argv[1]);
    // Use `htons` to convert the port number from host byte order to network byte order.
    // The port is passed as the second command-line argument.
    server_addr.sin_port = htons(atoi(argv[2]));

    // 3. Bind the socket to the server address and port.
    // This assigns the local address to the socket, allowing it to listen for incoming messages.
    if (bind(sockfd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("UDP Receiver is running on IP %s, Port %s.\n", argv[1], argv[2]);
    printf("Waiting for a message...\n");

    // The main communication loop.
    while (1) {
        // Clear the buffer before receiving new data.
        memset(buffer, 0, sizeof(buffer));
        addr_len = sizeof(client_addr);

        // 4. Receive a message from the sender.
        // `recvfrom` is a blocking call, it will wait here until a message is received.
        // `client_addr` will be populated with the sender's address and port.
        if (recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *)&client_addr, &addr_len) < 0) {
            perror("Recvfrom failed");
            close(sockfd);
            exit(EXIT_FAILURE);
        }

        // Print the received message.
        printf("Received message from Sender: %s\n", buffer);

        // Check if the received message is "exit".
        if (strcmp(buffer, "exit") == 0) {
            printf("Sender closed the connection. Exiting...\n");
            break;
        }

        // 5. Prompt the user for a message to send back.
        printf("Enter message to send (or 'exit'): ");
        // Read the message from standard input.
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            // Handle read error.
            perror("Fgets failed");
            break;
        }
        // Remove the newline character `\n` at the end of the input string.
        buffer[strcspn(buffer, "\n")] = 0;

        // 6. Send the message to the sender.
        // We use the `client_addr` obtained from `recvfrom` to send back to the correct host.
        if (sendto(sockfd, buffer, strlen(buffer), 0, (const struct sockaddr *)&client_addr, addr_len) < 0) {
            perror("Sendto failed");
            close(sockfd);
            exit(EXIT_FAILURE);
        }

        // Check if the sent message is "exit".
        if (strcmp(buffer, "exit") == 0) {
            printf("Exiting...\n");
            break;
        }
    }

    // 7. Close the socket.
    close(sockfd);
    return 0;
}

