// sender.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define MAX_BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    // A socket file descriptor.
    int sockfd;
    // The buffer to store messages.
    char buffer[MAX_BUFFER_SIZE];
    // The length of the address structure.
    socklen_t addr_len;
    // This structure holds the receiver's address.
    struct sockaddr_in receiver_addr;

    // Check for the correct number of command-line arguments.
    // The program name, receiver IP, and receiver port are expected.
    if (argc != 3) {
        printf("Usage: %s <Receiver's IP> <Receiver's Port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // 1. Create a UDP socket.
    // AF_INET for IPv4, SOCK_DGRAM for UDP.
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Initialize the receiver_addr structure to zero.
    memset(&receiver_addr, 0, sizeof(receiver_addr));

    // 2. Configure the receiver address structure.
    receiver_addr.sin_family = AF_INET;
    // The IP address from the command-line argument.
    receiver_addr.sin_addr.s_addr = inet_addr(argv[1]);
    // The port number from the command-line argument.
    receiver_addr.sin_port = htons(atoi(argv[2]));

    printf("UDP Sender is running. Sending to IP %s, Port %s.\n", argv[1], argv[2]);

    // The main communication loop.
    while (1) {
        // 3. Prompt the user for a message.
        printf("Enter message to send (or 'exit'): ");
        // Read the message from standard input.
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            // Handle read error.
            perror("Fgets failed");
            break;
        }
        // Remove the trailing newline character.
        buffer[strcspn(buffer, "\n")] = 0;

        // 4. Send the message to the receiver.
        if (sendto(sockfd, buffer, strlen(buffer), 0, (const struct sockaddr *)&receiver_addr, sizeof(receiver_addr)) < 0) {
            perror("Sendto failed");
            close(sockfd);
            exit(EXIT_FAILURE);
        }

        // Check if the sent message is "exit".
        if (strcmp(buffer, "exit") == 0) {
            printf("Exiting...\n");
            break;
        }

        // 5. Wait to receive a message back from the receiver.
        // `recvfrom` is a blocking call. The last two arguments are not used here
        // as we already know the address of the receiver we're communicating with.
        addr_len = sizeof(receiver_addr);
        if (recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *)&receiver_addr, &addr_len) < 0) {
            perror("Recvfrom failed");
            close(sockfd);
            exit(EXIT_FAILURE);
        }

        // Print the received message.
        printf("Received message from Receiver: %s\n", buffer);

        // Check if the received message is "exit".
        if (strcmp(buffer, "exit") == 0) {
            printf("Receiver closed the connection. Exiting...\n");
            break;
        }
    }

    // 6. Close the socket.
    close(sockfd);
    return 0;
}

